<?php

return [
  'layout_name' => 'mvp',
	'layout_path' => 'layout',
	'module_path' => [
        'Application' => 'module/application',
        'Page' => 'module/page'
  ]
];
