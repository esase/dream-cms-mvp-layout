<?php

return [
    'compatable' => '2.3.2',
    'version' => '1.0.0',
    'vendor' => 'eSASe',
    'vendor_email' => 'alexermashev@gmail.com'
];
