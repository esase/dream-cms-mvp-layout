MVP layout

compatible:   2.3.2
version:      1.0.0
vendor:       eSASe
vendor_email: alexermashev@gmail.com

Included layouts and templates for:

    module: Application
    version: 2.3.2
    vendor:  eSASe
    vendor email: alexermashev@gmail.com

    module: Page
    version: 2.3.2
    vendor:  eSASe
    vendor email: alexermashev@gmail.com

    module: Comment
    version: 1.0.1
    vendor:  eSASe
    vendor email: alexermashev@gmail.com

    module: News
    version: 1.0.5
    vendor:  eSASe
    vendor email: alexermashev@gmail.com
